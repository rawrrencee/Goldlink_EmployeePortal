<footer class="main-footer">
    <strong>Copyright &copy; <?php echo date("Y"); ?>
    <a href="https://goldlinkasia.com" target="_blank">
    Goldlink Asia Distribution Pte Ltd</a>
    </strong>
    All rights reserved.
</footer>